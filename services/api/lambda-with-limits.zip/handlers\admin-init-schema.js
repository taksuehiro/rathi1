"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const db_1 = require("../lib/db");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// ⚠️ 重要: Lambda実行時のパス解決
// __dirnameはビルド後のdistディレクトリを指す
const migrationsDir = path.join(__dirname, '../migrations');
/**
 * マイグレーションファイルを読み込んで実行
 */
async function runMigration(filename) {
    const migrationPath = path.join(migrationsDir, filename);
    if (!fs.existsSync(migrationPath)) {
        throw new Error(`Migration file not found: ${filename}`);
    }
    const sqlContent = fs.readFileSync(migrationPath, 'utf-8');
    const pool = await (0, db_1.getPool)();
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        // SQLファイル全体を一度に実行
        console.log(`Executing migration: ${filename}`);
        await client.query(sqlContent);
        await client.query('COMMIT');
        console.log(`Migration completed: ${filename}`);
    }
    catch (error) {
        await client.query('ROLLBACK');
        console.error(`Migration failed: ${filename}`, error);
        throw new Error(`Migration ${filename} failed: ${error.message}`);
    }
    finally {
        client.release();
    }
}
async function handler(event) {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers, body: '' };
    }
    try {
        // イベントパラメータからマイグレーション版を取得
        // bodyがJSON文字列の場合とオブジェクトの場合の両方に対応
        let body = {};
        if (event.body) {
            try {
                body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            }
            catch (e) {
                // JSONパースに失敗した場合は空オブジェクト
            }
        }
        const version = body.migrationVersion || event.queryStringParameters?.migrationVersion || 'all';
        const executedMigrations = [];
        // ⚠️ 'all'の場合は001→002の順序で実行
        if (version === 'all' || version === '001') {
            await runMigration('001_initial_schema.sql');
            executedMigrations.push('001');
        }
        if (version === 'all' || version === '002') {
            await runMigration('002_add_position_limits.sql');
            executedMigrations.push('002');
        }
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                success: true,
                message: 'Migration executed successfully',
                version,
                executedMigrations
            }),
        };
    }
    catch (error) {
        console.error('Migration error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: {
                    code: 'MIGRATION_ERROR',
                    message: error.message,
                    details: error.stack
                }
            }),
        };
    }
}

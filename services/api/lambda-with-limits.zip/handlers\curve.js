"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const db_1 = require("../lib/db");
async function handler(event) {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: '',
        };
    }
    try {
        const asOf = event.queryStringParameters?.asOf;
        if (!asOf) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: { code: 'BAD_REQUEST', message: 'asOf is required' },
                }),
            };
        }
        const result = await (0, db_1.query)(`SELECT * FROM futures_curve
       WHERE as_of_date = $1
       ORDER BY tenor_months`, [asOf]);
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                asOf,
                curve: result.rows.map((row) => ({
                    tenorMonths: row.tenor_months,
                    futuresPriceUsd: parseFloat(row.futures_price_usd),
                    priceSource: row.price_source,
                })),
            }),
        };
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: { code: 'INTERNAL_ERROR', message: error.message },
            }),
        };
    }
}

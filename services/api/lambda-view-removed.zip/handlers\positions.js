"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const db_1 = require("../lib/db");
async function handler(event) {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: '',
        };
    }
    try {
        const asOf = event.queryStringParameters?.asOf;
        if (!asOf) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: { code: 'BAD_REQUEST', message: 'asOf is required' },
                }),
            };
        }
        const result = await (0, db_1.query)(`SELECT * FROM position_components
       WHERE as_of_date = $1 AND scope = 'TOTAL'
       ORDER BY component_code`, [asOf]);
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                asOf,
                components: result.rows.map((row) => ({
                    componentCode: row.component_code,
                    qtyMt: row.qty_mt ? parseFloat(row.qty_mt) : null,
                    amountUsd: row.amount_usd ? parseFloat(row.amount_usd) : null,
                    notes: row.notes,
                })),
            }),
        };
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: { code: 'INTERNAL_ERROR', message: error.message },
            }),
        };
    }
}
